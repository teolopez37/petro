(function() {

	window.config = {
//		wsUrl : 'http://190.152.15.47:8090/ESMOVILJE/servlet/',
		 wsUrl : 'http://www7.eppetroecuador.ec:8090/ESMOVILJE/servlet/',
		defaultTimeout : 45000,
	};

	window.constants = {
		defaultFailMessage : 'Ha ocurrido un error, por favor intentalo nuevamente mas tarde',

	};

})(jQuery);